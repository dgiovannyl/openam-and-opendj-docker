# openam-and-opendj-docker
OpenAM and OpenDJ setup using docker and openam-configurator-tool
